<meta charset="UTF-8">
<?php define('APP', 'suehirotei');?>
<link rel="stylesheet" href="css/com.css">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/driver.js"></script>
<script type="text/javascript" src="js/api.js"></script>
<script type="text/javascript" src="js/frame.js"></script>
<script type="text/javascript" src="js/debug.js"></script>
<script type="text/javascript" src="js/main.js"></script>
