<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper onmove">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
      </div>
      <div class="undermessage">
        移動中
      </div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  setAnnounce('onmove')
  setOnmoveAudio()
  set_current_destination()
  var array = []
  array[0] = '通常走行'
  array[1] = '連続走行'
  array[2] = '拠点走行'
  array[3] = '巡回走行'
  var text
  if (getVariable('turnaround') >0) {
    text = '往復モード'
  } else {
    text = array[getVariable('trip_mode')]
  }
  setUnderMessage(text)
</script>
<!-- タイマースクリプト -->
<script>
  var countup = function(){
  }
  setInterval(countup, 1000);
</script>
