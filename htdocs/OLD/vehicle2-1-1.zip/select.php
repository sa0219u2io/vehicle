<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        目的地を選択してください
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div id="selectcontaier" class="selection"></div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  setMainMessage('目的地を選択してください')
  get_current_location()
  mode = getVariable('trip_mode')
  if (mode == 1) {
    transScreen('sequence')
  } else {
    setTimeout(set_destination_list,500)
  }
</script>

<!-- タイマースクリプト -->
<script>
  setTimeout(function(){setAnnounce('select')}, 200)
</script>

<!-- ループスクリプト -->
<script>
  var countup = function(){
    // checktimer();
  }
  setInterval(countup, 10000);
</script>
