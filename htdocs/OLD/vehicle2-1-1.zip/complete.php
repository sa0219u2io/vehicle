<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        目的に到着しました
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div id="comp_img"></div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<script>
  get_current_location()
  setTimeout(do_complete(), 500)
</script>
