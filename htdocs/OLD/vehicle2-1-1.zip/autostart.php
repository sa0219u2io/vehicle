<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="messagearea">
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div id="selectcontaier" class="autostart">

        </div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  auto_move()
</script>
<!-- タイマースクリプト -->
<script>
let count = 0;
let i = 0;
const countUp = () => {
  i++
  setUnderMessage(i+'秒経過')
}
setInterval(countUp, 1000)
</script>
