<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        <p>マークが２個読める位置にロボットを移動し<br>【設置完了】ボタンを押してください</p>
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div class="resetinstruction">
            <img src="asset/image/reset_1.png">
            <img src="asset/image/reset_2.png">
            <img src="asset/image/reset_3.png"><br><br><br>
            <div id="button"></div>
        </div>

      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<script>
  clearMoveStatus()
  setVariable('onrelocate', 1)
</script>
<script>
  let mode = getParam('mode');
  let timespan = 20000;
  if (!mode||mode == 0) {
    timespan = 10;
  }
  var countup = function(){
    $("#button").empty();
    $('#button').append('<a href="select.php?angle=99"><button class="reset">設置完了</button></a>&emsp;');
    $('#button').append('<button class="resume" onclick=resume_move()>元の経路に復帰</button>');
  }
  setInterval(countup, timespan);
  setTimeout(function(){setAnnounce('relocate')}, 200)
</script>
