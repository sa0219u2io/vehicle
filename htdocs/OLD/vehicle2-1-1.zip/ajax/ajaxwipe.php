<?php
  $filename = '../asset/json/temp_variable.json';
  unlink($filename);
  echo('erase');
  return;
