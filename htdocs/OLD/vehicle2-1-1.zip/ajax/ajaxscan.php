<?php
  $init_filename = '../asset/json/variable.json';
  $filename = '../asset/json/temp_variable.json';
  if (file_exists($filename)) {
    $variable = file_get_contents($filename);
  } else {
    $variable = file_get_contents($init_filename);
  }
  echo $variable;
  return;
