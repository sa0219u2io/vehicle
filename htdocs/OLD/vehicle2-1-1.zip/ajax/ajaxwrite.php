<?php
  $list = $_POST;
  header("Content-type: application/json; charset=UTF-8");
  $filename = '../asset/json/temp_variable.json';
  //chmod($filename, 0777);
  if (file_exists($filename)) {
    
  } else {
    touch($filename);
  }
  file_put_contents($filename, json_encode($list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
  echo json_encode($list);
  return;
