<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        目的地を順番に選択してください
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div id="sequencecontainer" class="sequence"></div>
        <div id="sequencepannel"></div>
        <div id="sequencego"></div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  get_current_location()
  mode = getVariable('trip_mode')
  if (mode == 0) {
    transScreen('select')
  }
  setTimeout(set_destination_list_sequence,100)
  writeVariable()
</script>
<!-- タイマースクリプト -->
<script>
  var countup = function(){
    // checktimer();
  }
  setInterval(countup, 10000);
  setTimeout(function(){setAnnounce('sequence')}, 200)
</script>
