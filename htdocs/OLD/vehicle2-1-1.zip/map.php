<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        地図を選択してください
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div id="selectcontaier" class="selection"></div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  setMaps()
  function changeMap(map_id) {
    setVariable('current_map_id', map_id)
    writeVariable();
    setTimeout(function() {req_change_map(map_id)}, 1000)
  }
</script>
<!-- タイマースクリプト -->
<script>

</script>
<!-- ループスクリプト -->
<script>
  var countup = function(){

  }
  //setInterval(countup, 10000);
</script>
