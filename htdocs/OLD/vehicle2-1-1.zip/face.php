<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper onmove">
      <a href="select.php" class="widera"> </a>
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
      </div>
      <div class="undermessage">
        <div id="mypos"></div>
      </div>
      <div class="main">
      </div>
      <!-- 以上、コンテンツ -->

    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
</script>
<!-- タイマースクリプト -->
<script>
  var countup = function(){
  }
  setInterval(countup, 1000);
</script>
