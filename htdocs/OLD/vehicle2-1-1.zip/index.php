<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        運搬モードを起動します
      </div>
      <div class="undermessage">
      </div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  init()
  setUnderMessage(mainversion)
  get_destination_list()
  setAnnounce('wakeup')
</script>
<!-- タイマースクリプト -->
<script>
  function checkCurrentMap() {
    map_id = parseInt(getVariable('current_map_id'))
    if (map_id == 0) {
      transScreen('map')
    } else {
      transScreen('select')
    }
  }
  setTimeout(checkCurrentMap, 3000)
</script>
<!-- ループスクリプト -->
<script>
  var countup = function(){

  }
  //setInterval(countup, 10000);
</script>
