/////////////////////////////////////////////////////////////////////////////////////////
//初期設定
/////////////////////////////////////////////////////////////////////////////////////////
//debug 0: 本番, 1: デバッグ
const debug = 0
const appname = 'vehicle'
const webroot = 'http://localhost/'
const variablefilename = 'temp_variable'

//systemUIなしでデバッグしたいとき
if (debug == 0)  {
  var systemUI = window.parent.SystemUI
} else {
  var systemUI = window
}
const broadcast = new BroadcastChannel('System')
const mainversion = appname + '2.1.1'

/////////////////////////////////////////////////////////////////////////////////////////
//共通イニシャル処理
/////////////////////////////////////////////////////////////////////////////////////////
//変数の初期化
function init() {
  console.log('APP started; '+mainversion)
  scanVariable()
  resetTemp()
  setVariable('log', '起動');
}

/////////////////////////////////////////////////////////////////////////////////////////
//複合処理関数
/////////////////////////////////////////////////////////////////////////////////////////
//移動指示
function move(destid) {
  if (destid == '') {
    alert("不正な地図です。管理者に連絡してください");
    return false;
  }
  current_location = getVariable('current_destination_id')
  setVariable('move_from', current_location)
  setVariable('move_to', destid)
  angle = getParam('angle');

  //再設置なら
  if (getVariable('onrelocate')==0) {
   console.log('目的地移動指示:'+ destid)
   req_move(destid);

  //方向がセットされていれば、再設置
  } else {
   var return_type = "1"  //新規経路指示
   console.log('経路復帰指示:'+ destid)
   req_relocate(destid);
  }
}

//トレースモード開始指示
function do_trace() {
  let start = getVariable('tracestart');
  let goal = getVariable('tracegoal');

  if (start!=-1) {
    if (goal!=-1) {
      req_section_route_trace(start, goal);
      return;
    }
  } else {
    if (goal !=-1) {
      setUnderMessage('区間設定が不正のためトレースを中止しました');
      return;//トレースさせない
    }
  }
  console.debug(start)
  console.debug(goal)
  req_route_trace()
}

//移動完了時処理
function do_complete() {
  //ログに蓄積
  var logs = getVariable('log')
  var current_destination_id = getVariable('current_destination_id')
  res = getVariable('dl_now_array')
  destination_list_array = JSON.parse(res)
  current_goal_name = destination_list_array[current_destination_id]
  logs = logs + ',' + current_goal_name;
  setVariable('log', logs)
  turnaround = getVariable('turnaround');
  setVariable('ontrace', 0);

  //走行モードの取得
  trip_mode = getVariable('trip_mode');
  switch (trip_mode) {
    case '0': //通常走行モード
      if (turnaround > 0) {
        move_from = getVariable('move_from')
        move_to = getVariable('move_to')
        turnaround_count = getVariable('turnaround_count')
        max = turnaround*2
        if (turnaround_count >= max) {
          //終了
          console.log('往復走行モード：目的地到着');
          time = getVariable('comp_wait')*1000
          setAnnounce('complete');
          setVariable('turnaround_count', 1)
          setTimeout(function(){transScreen('select')}, time)
        } else {
          console.log('往復走行モード：往復中');
          turnaround_count++
          setVariable('turnaround_count', turnaround_count)
          time = getVariable('comp_wait')
          setMainMessage(time + '秒後に折返し移動を開始します');
          time = time*1000
          setTimeout(function(){req_move(getVariable('move_from'))}, time)
        }
      } else {
        console.log('通常走行モード：目的地到着');
        time = getVariable('comp_wait')*1000
        setAnnounce('complete');
        setTimeout(function(){transScreen('select')}, time)
      }
      break;
    case '1': //連続走行モード
      transScreen('autostart')
      break;
    case '2': //拠点走行モード
      transScreen('autostart')
      break;
    case '3': //巡回走行モード
      transScreen('autostart')
      break;
    default:

  }
}

//自動移動開始
function auto_move() {
  //走行モードの取得
  trip_mode = getVariable('trip_mode');
  current_destination_id = getVariable('current_destination_id');
  console.log(trip_mode);
  var nextid
  switch (trip_mode) {
    case '1': //連続走行モード
    console.log('連続走行')
    sequencearray = getVariable('sequencearray')
    array = JSON.parse(sequencearray);
    i = getVariable('sequencei')
    i++
    count = Object.keys(array).length;

    //連続走行スタックに目的地がスタックされているか確認
    if (i == count) {
      //最終目的の場合
      if (turnaround > 0) {
        //往復モードなら
        setVariable('sequencei', 1)
        time = getVariable('sequence_wait')
        //console.log(time)
        setMainMessage(time + '秒後に自動で移動を開始します');
        time = time*1000
        nextid = array[0]
        console.log(nextid)
        setVariable('sequencei', i)
        setAnnounce('autostart')
        setVariable('move_from', current_destination_id)
        setVariable('move_to', nextid)
        setTimeout(function(){req_move(nextid)}, time)
      } else {
        //シングルモードなら
        setVariable('sequencei', 1)
        transScreen('select')
      }
    } else {
      //次の目的地がある場合
      time = getVariable('sequence_wait')
      //console.log(time)
      setMainMessage(time + '秒後に自動で移動を開始します');
      time = time*1000
      nextid = array[i]
      console.log(nextid)
      setVariable('sequencei', i)
      setVariable('move_from', current_destination_id)
      setVariable('move_to', nextid)
      setAnnounce('autostart')
      setTimeout(function(){req_move(nextid)}, time)
    }
    break;

    case '2': //拠点走行モード
      console.log('拠点走行')
      nextid = getVariable('hub_destination_id');
      if (current_destination_id == nextid) {
        transScreen('select')
      }
      time = getVariable('hub_wait')
      setMainMessage(time + '秒後に自動で移動を開始します');
      time = time*1000
      setVariable('move_from', current_destination_id)
      setVariable('move_to', nextid)
      setTimeout(function(){req_move(nextid)}, time)
    break;

    case '3': //巡回走行モード
      console.log('巡回走行')
      roundarray = getVariable('roundarray')
      array = JSON.parse(roundarray);
      i = getVariable('roundi')
      i++
      count = Object.keys(array).length;

      //連続走行スタックに目的地がスタックされているか確認
      if (i == count) {
        //最終目的の場合
        if (turnaround > 0) {
          //往復モードなら
          setVariable('roundi', 1)
          time = getVariable('round_wait')
          //console.log(time)
          setMainMessage(time + '秒後に自動で移動を開始します');
          time = time*1000
          nextid = array[0]
          console.log(nextid)
          setVariable('roundi', i)
          setVariable('move_from', current_destination_id)
          setVariable('move_to', nextid)
          setTimeout(function(){req_move(nextid)}, time)
        } else {
          //シングルモードなら
          setVariable('roundi', 1)
          transScreen('select')
        }
      } else {
        //次の目的地がある場合
        time = getVariable('round_wait')
        //console.log(time)
        setMainMessage(time + '秒後に自動で移動を開始します');
        time = time*1000
        nextid = array[i]
        console.log(nextid)
        setVariable('roundi', i)
        setVariable('move_from', current_destination_id)
        setVariable('move_to', nextid)
        setAnnounce('autostart')
        setTimeout(function(){req_move(nextid)}, time)
      }
    break;
    default:
      setVariable('sequencei', 1)
      setVariable('roundi', i)
      setVariable('trip_mode', 0)
      transScreen('select')
    break;
  }
  var sampleButton = document.createElement( "BUTTON" )
  sampleButton.class = "selectdestination"
  sampleButton.value = nextid
  res = getVariable('destination_list_array')
  destination_list_array = JSON.parse(res)
  sampleButton.innerText = destination_list_array[nextid]+'へ移動する'
  sampleButton.id = nextid
  document.getElementById("selectcontaier").appendChild( sampleButton )
  document.getElementById(nextid).onclick = function() {
    var nextid = this.value
    move(nextid)
  };
}

//再設置時・最終目的地自動移動
function resume_move() {
  var destid = getVariable('move_to');
  console.log('最終目的地経路復帰指示='+ destid);
  req_relocate(destid);
}



/////////////////////////////////////////////////////////////////////////////////////////
//コールバック関数
/////////////////////////////////////////////////////////////////////////////////////////
//登録MAP確認
function callback_MGD (res) {
  url = res.data.mapimage_filepath
  console.log("登録MAPURL(" + url +")")
  setVariable(url);
  //一回リストを削除
  $("#map").empty();
  $('#map').append('<img src="' + url + '">');
  $('#resetmap').append('<img src="' + url + '">');
}

//障害物センサデータ表示
function callback_GSD (res) {
  //超音波センサ反応を調べる
  console.log(res)
  text = '[胸上]:' +res.data.ids.detection_distance[2] +
  ', [胸下]:'  +res.data.ids.detection_distance[3]+
  '<br> [右壁]:'  +res.data.ids.detection_distance[0]+
  ', [右足元]:'  +res.data.ids.detection_distance[4]+
  ', [正面足元]:'  +res.data.uls.detection_distance+
  ', [左足元]:'  +res.data.ids.detection_distance[5]+
  ', [左壁]:'  +res.data.ids.detection_distance[1]
  //setUnderMessage(text);
  sensordata = JSON.stringify(res)
  sensorlog = getVariable('sensorlog')
  if (sensorlog) {
    sensorlog = sensorlog+','+sensordata
  } else {
    sensorlog = sensordata
  }
  var target = [];
  target[1] =  res.data.ids.detection_existence[2]   //胸上
  target[2] =  res.data.ids.detection_existence[3]   //胸下
  target[3] =  res.data.ids.detection_existence[0]   //右壁
  target[4] =  res.data.ids.detection_existence[4]   //右足元
  target[5] =  res.data.uls.detection_existence      //正面足元
  target[6] =  res.data.ids.detection_existence[5]   //左足元
  target[7] =  res.data.ids.detection_existence[1]   //左壁

  var data = [];
  data[1] =  res.data.ids.detection_distance[2]   //胸上
  data[2] =  res.data.ids.detection_distance[3]   //胸下
  data[3] =  res.data.ids.detection_distance[0]   //右壁
  data[4] =  res.data.ids.detection_distance[4]   //右足元
  data[5] =  res.data.uls.detection_distance      //正面足元
  data[6] =  res.data.ids.detection_distance[5]   //左足元
  data[7] =  res.data.ids.detection_distance[1]   //左壁

  for (var i = 1; i < 8; i++) {
    if (target[i] > 0) {
      $('.halt-sensor-'+i).addClass('halt-show')
      $('.halt-sensor-'+i).text(data[i])
    }
  }

  setVariable('sensorlog', sensorlog)
  setVariable('sensor_target' )
}

//現在地情報取得指示
function callback_GCL (res) {
  current_destination_id = res.data.destination_id
  current_mark_index = res.data.mark_index
  current_mark_id = res.data.mark_id
  if (current_destination_id) {
    console.log("現在地取得受信(" + current_destination_id +")")
    setVariable('current_destination_id', current_destination_id)
    setVariable('current_mark_index', current_mark_index)
    setVariable('current_mark_id', current_mark_id)
  }

  return
}

//目的地情報取得指示
function callback_GDL (res) {
  var current_map_id = getVariable('current_map_id')
  dl_all = JSON.stringify(res)
  setVariable('dl_all', dl_all)
  deslist = res.data.map_list
  //console.log(deslist)
  var obj = new Object;
  var maps = new Object;
  for (var i = 0; i < deslist.length; i++) {
    mid = deslist[i].map_id
    maps[mid] = deslist[i].map_name
    subobj = new Object;
    for (var j = 0; j < deslist[i].destination_list.length; j++) {
      did = deslist[i].destination_list[j].destination_id
      console.log(did)
      dname = deslist[i].destination_list[j].destination_name
      console.log(dname)
      subobj[did] = dname
    }
    obj[mid] = subobj
    if (current_map_id == mid) {
      var selobj = JSON.stringify(subobj)
      setVariable('dl_now_array', selobj)
    }
    console.log(obj)
  }
  maps = JSON.stringify(maps)
  setVariable('map_list', maps)
  dl_all_array = JSON.stringify(obj)
  setVariable('dl_all_array', dl_all_array)
  current_map_id = parseInt(getVariable('current_map_id'))
  if (current_map_id > 0) {
    //現在マップが設定されていれば

  }
}

//目的地移動指示
function callback_RM (res) {
  var result_cd =res.data.result_cd;
  //エラーが返ってきたら
  if (result_cd =="1" ) {
    alert("目的地の選択が不正です");
  } else {
    window.location.href = webroot+appname+'/onmove.php';
  }
}

//経路復帰指示
function callback_RRL (res) {
  var result_cd =res.data.result_cd;
  //エラーが返ってきたら
  if (!res.type == 'req_relocate')  {
    console.log('infor_robot_status無視');
    window.location.href = webroot+appname+'/onmove.php';
  }
  if (result_cd =="1" ) {
    alert("目的地の選択が不正です");
  } else {
    window.location.href = webroot+appname+'/onmove.php';
  }
}

//現在地情報取得指示
function callback_GMS(res) {
  var move_status = res.data.move_status

  if (move_status == "-1") { //モータ制御マイコン未接続
    deleteturnaround();
    //window.location.href = "http://localhost/transport/halt.php";
  } else if (move_status == "0") {  //移動待機中→目的到着
    var now = res.data.destination_id
    console.log('停止原因:' + move_status + ' (移動待機中→目的到着)');
    do_complete();

  } else if (move_status == "3") {  //障害物検知停止
    window.location.href = webroot+appname+'/halt.php';
    console.log('停止原因:' + move_status + ' (障害物検知停止)');

  } else if (move_status == "4") {  //動作障害
    deleteturnaround();
    console.log('停止原因:' + move_status + ' (動作障害)');
    window.location.href = webroot+appname+'/reset.php';

  } else if (move_status == "5") {  //バンパセンサ反応
    deleteturnaround();
    console.log('停止原因:' + move_status + ' (バンパセンサ反応)');
    window.location.href = webroot+appname+'/reset.php';

  } else if (move_status == "6") {  //マークロスト
    deleteturnaround();
    console.log('停止原因:' + move_status + ' (マークロスト)');
    window.location.href = webroot+appname+'/reset.php';

  } else if (move_status == "8") {  //非常停止
    deleteturnaround();
    console.log('停止原因:' + move_status + ' (非常停止)');
    window.location.href = webroot+appname+'/reset.php';

  } else {
    deleteturnaround()
    console.log('停止原因:' + move_status + ' (不明・通信エラー)');
    window.location.href = webroot+appname+'/reset.php';
  }
  return
}

//地図切替完了
function callback_RCM(res) {
  writeVariable()
  transScreen('index')
}

/////////////////////////////////////////////////////////////////////////////////////////
//部品関数
/////////////////////////////////////////////////////////////////////////////////////////
//目的地一覧を表示
function set_destination_list() {
  res = getVariable('dl_now_array')
  if (res) {
    deslist = JSON.parse(res)
    current_map_id = getVariable('current_map_id')
  } else {
    //目的地リスト取得失敗したらアプリ再起動
    transScreen('index')
  }
  $("#selectcontaier").empty();
  var current_destination_id = getVariable('current_destination_id')
  mode = getVariable('trip_mode')
  // if (mode == 3) {
  //   //巡回走行モードなら
  //   var sampleButton = document.createElement( "BUTTON" )
  //   sampleButton.class = "selectdestination"
  //   i = 1;
  //   sampleButton.value = deslist[i].destination_id
  //   //console.log("目的地(" + deslist[i].destination_id + "):" + deslist[i].destination_name)
  //   sampleButton.innerText = '巡回'
  //   sampleButton.id = deslist[i].destination_id
  //   document.getElementById("selectcontaier").appendChild( sampleButton )
  //   document.getElementById(deslist[i].destination_id).onclick = function() {
  //     var destid = this.value
  //     move(destid)
  //   };
  //
  //   return
  // }
  //再設置画面なら
  if (getVariable('onrelocate')==1) {
    current_destination_id = "";
  }
  //console.log(deslist)

  deslistlen = Object.keys(deslist).length

  Object.keys(deslist).forEach(function (key) {
    if (key == current_map_id) {
      $('#selectcontaier').append('<div class="select float" id="current_location">'+ deslist[key] +'</div>')
    } else {
      $('#selectcontaier').append('<div class="select float" onclick="move(\''+ key+'\')">'+ deslist[key] +'</div>')
    }

  });
}

//目的地一覧を表示
function set_destination_list_sequence() {
  res = getVariable('destination_list')
  if (res) {
    destination_list = JSON.parse(res)
    deslist = destination_list.data.list
  } else {
    //目的地リスト取得失敗したらアプリ再起動
    window.location.href = webroot+appname+'/index.php';
  }
  $("#sequencecontainer").empty();
  var current_destination_id = getVariable('current_destination_id')
  //再設置画面なら
  if (getVariable('onrelocate')==1) {
    current_destination_id = "";
  }
  for (var i = 0; i < deslist.length; i++) {
    //クッキーに保存されている現在地と一致する目的地は選択不可
    var sampleButton = document.createElement( "BUTTON" )
    sampleButton.class = "sequencecontainer"
    sampleButton.value = deslist[i].destination_id

    console.log("目的地(" + deslist[i].destination_id + "):" + deslist[i].destination_name)
    sampleButton.innerText = deslist[i].destination_name
    sampleButton.id = deslist[i].destination_id
    document.getElementById("sequencecontainer").appendChild( sampleButton )
    document.getElementById(deslist[i].destination_id).onclick = function() {
      var destid = this.value
      putSequenceArray(destid)
    };
  }
  clearSequenceArray();
  putSequenceArray(current_destination_id);
}

//現在の目的地を表示
function set_current_destination() {
  ontrace = getVariable('ontrace')
  if (ontrace==1) {
    $('.mainmessage').append('<p>トレースモード</p>')
    return
  }
  res = getVariable('dl_now_array')
  destination_list_array = JSON.parse(res)
  move_to = getVariable('move_to')
  move_to_name = destination_list_array[move_to]
  $('.mainmessage').append('<p>'+move_to_name+'へ移動中です</p>')
}

//移動時音楽設定
function setOnmoveAudio() {
  var num = getVariable('music');
  readJson('music', num);
}

/////////////////////////////////////////////////////////////////////////////////////////
//一時変数操作
/////////////////////////////////////////////////////////////////////////////////////////
//その他変数初期化
function resetTemp() {
  setVariable('move_from', 0)
  setVariable('move_to', 0)
  setVariable('ontrace', 0)
  setVariable('current_destination', 0)
  setVariable('current_rfid', 0)
  setVariable('turnaround', 0)
  setVariable('turnaround_count', 0)
  setVariable('api', "")
  setVariable('sequencearray', "")
  setVariable('roundarray', "")
  setVariable('sequencei', 1)
  setVariable('roundi', 1)
  setVariable('sensor_target', "")
  setVariable('onrelocate', 0)
}

//一次変数消去
function clearMoveStatus() {
  setVariable('ontrace', 0)
  setVariable('turnaround', 0)
  setVariable('turnaround_count', 0)
  setVariable('sequencei', 1)
  setVariable('roundi', 1)
}
