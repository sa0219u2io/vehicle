<html>
  <head>
    <?php include('head.php'); ?>
  </head>
  <body>
    <div class="wrapper alertred">
      <?php include('frame.php'); ?>
      <!-- 以下、コンテンツ -->
      <div class="mainmessage">
        障害物検知のため移動を中断しました<br>障害物がなくなると自動で復帰します
      </div>
      <div class="undermessage">
      </div>
      <div class="main">
        <div class="haltdata">
          <img src="asset/image/buddychar.png">
          <div class="halt-sensor-1" id="halt-sensor"></div>
          <div class="halt-sensor-2" id="halt-sensor"></div>
          <div class="halt-sensor-3" id="halt-sensor"></div>
          <div class="halt-sensor-4" id="halt-sensor"></div>
          <div class="halt-sensor-5" id="halt-sensor"></div>
          <div class="halt-sensor-6" id="halt-sensor"></div>
          <div class="halt-sensor-7" id="halt-sensor"></div>
        </div>
      </div>
      <!-- 以上、コンテンツ -->
    </div>
  </body>
</html>
<!-- 起動時スクリプト -->
<script>
  get_sensor_data()
</script>
<!-- タイマースクリプト -->
<script>
  setTimeout(function(){setAnnounce('halt')}, 200)
</script>
