<?php
 header("Content-type: application/json; charset=UTF-8");
 $result = glob('../*');
 var_dump($result);

 return;
