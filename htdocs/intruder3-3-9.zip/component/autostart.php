<?php
  include('./template.php');
?>
<script>
  // setVariable('remoteAutorun', 'true');
  localStorage.setItem('remoteAutorun', 'true');
</script>